======================= Step1 ===========================
enter this code on terminal here we are using powershell
=========================================================

docker compose up --build -d

======================= Step2 ===========================
enter this URL's on the browser here we are using edge
=========================================================

======= Node 1 =======
http://localhost:8000/

======= Node 2 =======
http://localhost:8080/

======= Node 3 =======
http://localhost:8081/


======================= Step3 ===========================
This vesion works by full replication of data When a user
creates a patient in node 1 that patient is replicated
across all the other nodes, same as the rest of the nodes.
This is the same for all "CRUD" operations
=========================================================

*Note After a "CRUD" operation, like creating a patient for
example, all the other pages of the other nodes must be 
refreshed to visibly see the change. An alternative to this
is to check the logs in docker or the terminal.