from django.shortcuts import render,redirect
from .models import Member
from django.http import JsonResponse
import requests

# other nodes on the network, save data API
all_nodes_create = 'http://172.19.0.2:8000/api/save-data/','http://172.19.0.3:8000/api/save-data/','http://172.19.0.4:8000/api/save-data/'
# other nodes on the network, remove data API
all_nodes_delete = 'http://172.19.0.2:8000/api/remove-data/{}/','http://172.19.0.3:8000/api/remove-data/{}/','http://172.19.0.4:8000/api/remove-data/{}/'
# other nodes on the network, update data API
all_nodes_update = 'http://172.19.0.2:8000/api/update-data/{}/','http://172.19.0.3:8000/api/update-data/{}/','http://172.19.0.4:8000/api/update-data/{}/'

# ===============================
# ===== DEFAULT_PAGE_METHODS=====
# ===============================
# Note: these are none distributed methods they are just for testing
# ======== DEFAULT_PAGE ========
def index(request):
    member = Member.objects.all()
    return render(request,'index.html',{"members":member})

# ========= ADD_PATIENT_PAGE ========
def add(request):
    return render(request,'add.html')


# ========= STORE_PATIENT_TO_DB ========
def addrec(request):
    x = request.POST['firstname']
    y = request.POST['lastname']
    z = request.POST['country']
    
    member = Member()
    member.firstname = x
    member.lastname = y
    member.country = z 
    
    member.save()

# ========= UPDATE_PATIENT_PAGE ========
def update(request,id):
    member = Member.objects.get(id=id)  
    return render(request,'update.html',{"member":member})

# ========= ADD_PATIENT_TO_BD ========
def updaterec(request,id):
    x = request.POST['firstname']
    y = request.POST['lastname']
    z = request.POST['country']
    
    member = Member.objects.get(id=id)
    member.firstname = x
    member.lastname = y
    member.country = z
    
    member.save()
    return redirect("/")
    

# ========= DELETE_PATIENT_FROM_DB ========
def delete(request,id):
    member = Member.objects.get(id=id)
    member.delete()
    return redirect("/")
        
# ====================================
# ====== DISTRIBUTED_FUNCTIONS =======
# ====================================

# This function recieves a Post request and distubutes it to all nodes on the network

def saveToAll(request):
    if request.method == 'POST':
        form_data = request.POST
          
        for node in all_nodes_create:
            try:
                response = requests.post(node, data=form_data)
                print(f"data sent to {node} successfully")
            except: 
                print(f"data transfere to {node} unsuccessful")
            
            
    # return JsonResponse({'message': f'Data replication successful.'})
    return redirect("/")
        

# This method saves data to a node's DB

def saveToDB(request):
    if request.method == 'POST':
        try:
            # Save form data to Node B's database
            x = request.POST['firstname']
            y = request.POST['lastname']
            z = request.POST['country']
            
            member = Member()
            member.firstname = x
            member.lastname = y
            member.country = z 
            
            member.save()
            return JsonResponse({'message': 'Data saved to Node B successfully'})
        except Exception as e:
            return JsonResponse({'error': str(e)})
    return JsonResponse({'error': 'Invalid request method'})

# This function recieves a delete request given the patient_ID, and broadcasts it to all other nodes

def deleteFromAll(request,id):
    if request.method == 'GET':      
        for node in all_nodes_delete:
            try:
                response = requests.delete(node.format(id))
                print(f"data found in {node} successfully")
            except: 
                print(f"data transfere to {node} unsuccessful")
                return JsonResponse({'error':f'Invalid request method {response}'})
    else:
        return JsonResponse({'error': 'Invalid request method'})         
    # return JsonResponse({'message': f'Data replication successful.'})
    return redirect("/")
    
# This method removes data from a node's DB

def deleteFromDB(request,id):
    member = Member.objects.get(id=id)
    member.delete()
    return JsonResponse({'message': f'Data deletion successful.'})


# This function recieves an update request given the patient_ID, and broadcasts it to all other nodes

def updateOnAll(request,id):
    if request.method == 'POST':
        form_data = request.POST
          
        for node in all_nodes_update:
            try:
                response = requests.post(node.format(id),data=form_data)
                print(f"data found in {node} successfully")
            except: 
                print(f"data transfere to {node} unsuccessful")
                return JsonResponse({'error':f'Invalid request method {response}'})
    else:
        return JsonResponse({'error': 'Invalid request method'})         
    # return JsonResponse({'message': f'Data replication successful.'})
    return redirect("/")
    
# This method updates data on a node's DB

def updateOnDB(request,id):
    x = request.POST['firstname']
    y = request.POST['lastname']
    z = request.POST['country']
    
    member = Member.objects.get(id=id)
    member.firstname = x
    member.lastname = y
    member.country = z
    
    member.save()
    return JsonResponse({'message': f'Data update successful.'})