from django.urls import path
from . import views

# ***************************
# from .views import save_data_to_node_b
from .views import saveToDB
# from .views import delete

urlpatterns = [
    # *************
    #  CENTRALISED
    # *************
    # NOTE: For testing purposes only
    
    path('', views.index,name="index"),
    path('add/', views.add,name="add"),
    path('addrec/', views.addrec,name="addrec"),
    path('update/<int:id>/', views.update,name="update"),
    path('updaterec/<int:id>/', views.updaterec,name="updaterec"),
    path('delete/<int:id>/', views.delete,name="delete"), 
    
    # *************
    #  DISTRUBUTED
    # *************
    # This is our focus
    
    # Insert path
    path('save/',views.saveToAll,name="save_to_all"),
    path('api/save-data/', saveToDB, name='save_data_to_node'),
    
    # Edit path
    path("edit/<int:id>/", views.updateOnAll, name="update_data_on_all"),
    path("api/update-data/<int:id>/", views.updateOnDB, name="update_data_on_node"),
    
    # Remove path
    path("remove/<int:id>/", views.deleteFromAll, name="remove_data_from_all"),
    path('api/remove-data/<int:id>/', views.deleteFromDB, name="remove_data_from_node"),
]
